package com.example.loginpage;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class userpage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userpage);
    }
    public void validateID(View view) {
        Intent i6 = new Intent(getApplicationContext(), homePage.class);
        startActivity(i6);
    }

    public void docMap(View view) {
        Intent i8 = new Intent(getApplicationContext(),map.class);
        startActivity(i8);

    }
}
