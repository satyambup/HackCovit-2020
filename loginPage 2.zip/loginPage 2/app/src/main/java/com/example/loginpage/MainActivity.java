package com.example.loginpage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }


    public void userLogin(View view) {
        Intent i5 = new Intent(getApplicationContext(), userpage.class);
        startActivity(i5);
    }

    public void docLogin(View view) {
        Intent i1 = new Intent(getApplicationContext(), loginPage.class);
        startActivity(i1);
    }


}
